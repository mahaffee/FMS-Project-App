let button;
let temp =0;
let gameTemp =0;
//game1
let overCircle1_1 = false;
let overCircle1_2 = false;
let overCircle1_3 = false;
let overCircle1_4 = false;
let overCircle1_5 = false;
//game2
let overCircle2_1 = false;
let overCircle2_2 = false;
let overCircle2_3 = false;
let overCircle2_4 = false;
//game3
//game1
let locked1_1 = false;
let locked1_2 = false;
let locked1_3 = false;
let locked1_4 = false;
let locked1_5 = false;
//game2
let locked2_1 = false;
let locked2_2 = false;
let locked2_3 = false;
let locked2_4 = false;
//game 2 allow
let allow2_2 =false;
let allow2_3 =false;
let allow2_4 =false;
//game3
let locked3_1 = false;

let xspeed = 1.6;//shape speed
let yspeed = 1.9;//shape speed
let xdirection =1; //left or right
let ydirection =1;// top to bottom

let xpos, ypos;

//totals
let total1 =0;
let total2 =0;
let total3=0;
//let grandtotal =0;




//=======================================================================
function setup() {
  createCanvas(360, 600);
  background(0);
   
  var button = createButton('Home Page');
  button.position(0, 0);
  button.mousePressed(doMenu);
  
  var game1 = createButton('Game 1');
  game1.position(90, 0);
  game1.mousePressed(doGame1);
  
  var game2 = createButton('Game 2');
  game2.position(160, 0);
  game2.mousePressed(doGame2);
  
  var game3 = createButton('Game 3');
  game3.position(230, 0);
  game3.mousePressed(doGame3);
  

  //game 3 setup
  xpos =100;
  ypos = 100;
  
}

function draw(){
//
  fill(255);
  
  rect(10, 10, 340, 580, 5);
  
  if(temp ==0){
    allow2_2 =false;
    allow2_3 =false;
    allow2_4 =false;
     fill('purple');
    rect(10, 10, 340, 580, 5);
    textSize(32);
    fill(0);
    textAlign(CENTER, CENTER);
    text('Main Menu', 180, 300);
  }
  else if(temp ==1){///////////////////////////////////////////////////////
    allow2_2 =false;
    allow2_3 =false;
    allow2_4 =false;
    fill('rgb(199,85,196)');
     rect(10, 10, 340, 580, 5);
        textSize(32);
    fill(0);
    textAlign(CENTER, CENTER);
    text('Game 1', 180, 300);
    
    
    var game1Start = createButton('Start Game 1');
  game1Start.position(180, 570);
  game1Start.mousePressed(playGame1);
    
    //buttons -first
    if (gameTemp ==1){
      textSize(15);
      text('Score: '+ total1, 50, 560);
      ///////////////////////////////////////////////////////////////check circle 1
      fill('rgb(199,85,196)');
      if (dist(mouseX, mouseY, 100,100) < 30/2) {//game 1 button 1
        overCircle1_1= true;
        }
      else{
        fill('rgb(199,85,196)');
          circle(100,100, 30);
          overCircle1_1 =false;
      }
      if (!locked1_1) {
          fill(255, 128, 0);
          
          }
      circle(100,100, 30);
      ///////////////////////////////////////////////////////////////check circle 2
      fill('rgb(199,85,196)');
      if (dist(mouseX, mouseY, 200,200) < 30/2) {//game 1 button 2
        overCircle1_2= true;
        }
      else{
        fill('rgb(199,85,196)');
          circle(200,200, 30);
          overCircle1_2 =false;
      }
      if (!locked1_2) {
          fill(255, 128, 0);
          
          }
      circle(200,200, 30);
      ///////////////////////////////////////////////////////////////check circle 3
      fill('rgb(199,85,196)');
      if (dist(mouseX, mouseY, 100,200) < 30/2) {//game 1 button 3
        overCircle1_3= true;
        }
      else{
        fill('rgb(199,85,196)');
          circle(100,200, 30);
          overCircle1_3 =false;
      }
      if (!locked1_3) {
          fill(255, 128, 0);
          
          }
      circle(100,200, 30);
      ///////////////////////////////////////////////////////////////check circle 4
      fill('rgb(199,85,196)');
      if (dist(mouseX, mouseY, 300,400) < 30/2) {//game 1 button 4
        overCircle1_4= true;
        }
      else{
        fill('rgb(199,85,196)');
          circle(300,400, 30);
          overCircle1_4 =false;
      }
      if (!locked1_4) {
          fill(255, 128, 0);
          
          }
      circle(300,400, 30);
      ///////////////////////////////////////////////////////////////check circle 5
      fill('rgb(199,85,196)');
      if (dist(mouseX, mouseY, 200,500) < 30/2) {//game 1 button 5
        overCircle1_5= true;
        }
      else{
        fill('rgb(199,85,196)');
          circle(200,500, 30);
          overCircle1_5 =false;
      }
      if (!locked1_5) {
          fill(255, 128, 0);
          
          }
      circle(200,500, 30);
      
    }//end game 1
  }
  //==============================game 2===========================================
  ////////////////////////////////////////////
   else if(temp ==2){
    fill('rgb(170,56,147)')
     rect(10, 10, 340, 580, 5);
        textSize(32);
    fill(0);
    textAlign(CENTER, CENTER);
    text('Game 2', 180, 300);
    
  var game2Start = createButton('Start Game 2');
  game2Start.position(180,570);  
  game2Start.mousePressed(playGame2);
   
     if(gameTemp == 2) { 
     textSize(15);
    text('Score: '+ total2, 50, 560); ///=============================check circle 1===
      fill('rgb(170,56,147)');
    if (dist(mouseX, mouseY, 120,200) < 80/2) {//game 1 button 1
        overCircle2_1= true;
        }
      else{
        fill('rgb(170,56,147)');
          circle(120,200, 80);
          overCircle2_1 =false;
      }
      if (!locked2_1) {
          fill(255, 128, 0);
          
          }
      circle(120,200, 80);
       //=====================================================check circle 2=========
      if(allow2_2 == true){
       if (dist(mouseX, mouseY, 240,200) < 80/2) {//game 1 button 1
        overCircle2_2= true;
        }
      else{
        fill('rgb(170,56,147)');
          circle(240,200, 80);
          overCircle2_2 =false;
      }
      if (!locked2_2) {
          fill(255, 128, 0);
          
          }
      circle(240,200, 80);
      }
        //=====================================================check circle 3=========
      if(allow2_3 == true){
       if (dist(mouseX, mouseY, 120,400) < 80/2) {//game 1 button 1
        overCircle2_3= true;
        }
      else{
        fill('rgb(170,56,147)');
          circle(120,400, 80);
          overCircle2_3 =false;
      }
      if (!locked2_3) {
          fill(255, 128, 0);
          
          }
      circle(120,400, 80);
      }
        //=====================================================check circle 4=========
      if(allow2_4 == true){
       if (dist(mouseX, mouseY, 240,400) < 80/2) {//game 1 button 1
        overCircle2_4= true;
        }
      else{
        fill('rgb(170,56,147)');
          circle(240,400, 80);
          overCircle2_4 =false;
      }
      if (!locked2_4) {
          fill(255, 128, 0);
          
          }
      circle(240,400, 80);
      }

     }
   }
  //================================game 3==========================================
  else if(temp ==3){
    allow2_2 =false;
    allow2_3 =false;
    allow2_4 =false;
    fill('rgb(219,126,217)')
     rect(10, 10, 340, 580, 5);
        textSize(32);
    fill(0);
    textAlign(CENTER, CENTER);
    text('Game 3', 180, 300);
    
    var game3Start = createButton('Start Game 3');
    game3Start.position(180, 570);
    game3Start.mousePressed(playGame3);
    
      if(gameTemp ==3){// start game 3
        textSize(15);
        textAlign(LEFT);
      text('Score: '+ (total3/10), 50, 560);
      ///////////////////////////////////////////////////////////////check circle 1
      fill('rgb(199,85,196)');
      
        
        // Update the position of the shape
      xpos = xpos + xspeed * xdirection;
      ypos = ypos + yspeed * ydirection;

  // Test to see if the shape exceeds the boundaries of the screen
  // If it does, reverse its direction by multiplying by -1
      if (xpos > width - 50 || xpos < 50) {
        xdirection *= -1;
      }
      if (ypos > height - 50 || ypos < 50) {
        ydirection *= -1;
      }
        
        
        
        
        
        //moving circle
        
      if (dist(mouseX, mouseY, xpos,ypos) < 60/2) {//game 1 button 1
        overCircle3_1= true;
        total3 ++;
        if (!locked3_1) {
          fill(255, 0, 0);
          }
        else{
          fill(255, 255, 255);
          circle(100,100, 30);
          }
        }
      else{
        overCircle3_1=false;
      }
    circle(xpos,ypos, 50);
    
  }
    
  }//end game 3
  //================================else==========================================
  else{
  }
    noStroke();
}
//===============================functions==========================================
function doMenu() {
  temp =0;
}
function doGame1() {
  temp =1;
}
function doGame2() {
  temp =2;
}
function doGame3() {
  temp =3;
}
//=============================game 1 functions=====================================
function playGame1() {
  locked1_1 = false;
  locked1_2 = false;
  locked1_3 = false;
  locked1_4 = false;
  locked1_5 = false;
  gameTemp= 1;
}
//=============================game 2 functions=====================================
function playGame2(){
  locked2_1 = false; 
  gameTemp = 2;
}
//=============================game 3 functions=====================================
function playGame3() {
  
  gameTemp= 3;
}
 

function mouseClicked() {
  
  //==============================Game 1===============================
  if (overCircle1_1 == true) {
    locked1_1 = true;
    fill(255, 255, 255);
    total1 ++;
  } 
  if (overCircle1_2 == true) {
    locked1_2 = true;
    fill(255, 255, 255);
    total1 ++;
  } 
  if (overCircle1_3 == true) {
    locked1_3 = true;
    fill(255, 255, 255);
    total1 ++;
  } 
  if (overCircle1_4 == true) {
    locked1_4 = true;
    fill(255, 255, 255);
    total1 ++;
  } 
  if (overCircle1_5 == true) {
    locked1_5 = true;
    fill(255, 255, 255);
    total1 ++;
  } 
  
  //==============================Game 2===============================
if (overCircle2_1 == true) {
    locked2_1 = true;
    fill('rgb(0,255,0)');    
    total2 ++;
    allow2_2 = true;
  } 
  if (overCircle2_2 == true) {
    locked2_2 = true;
    fill('rgb(0,255,0)');
    total2 ++;
    allow2_3 = true;
  } 
  if (overCircle2_3 == true) {
    locked2_3 = true;
    fill('rgb(0,255,0)');
    total2 ++;
    allow2_4 = true;
  } 
  if (overCircle2_4 == true) {
    locked2_4 = true;
    fill('rgb(0,255,0)');
    total2 ++;
  } 
}
  //==============================Game 3===============================
  




